package com.subhadip.dynamicisland

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Round quick-action button on the Home page. */
private class Chip(val view: LinearLayout, private val glyphView: GlyphView, private val circle: GradientDrawable) {
    fun setActive(on: Boolean) {
        circle.setColor(if (on) Color.WHITE else Color.rgb(44, 44, 46))
        glyphView.tint = if (on) Color.BLACK else Color.WHITE
        glyphView.invalidate()
    }
}

class IslandOverlayService : Service() {

    /** Things the island can show, highest priority first. */
    enum class Page { CALL, NOTIF, TIMER, MEDIA, CHARGE, HOME }

    companion object {
        private const val CHANNEL = "dynamic_island_service"
        private const val NOTIFICATION_ID = 1001
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private val ACCENT = Color.rgb(89, 230, 210)
        private val GREEN = Color.rgb(48, 209, 88)
        private val RED = Color.rgb(255, 69, 58)
        private val ORANGE = Color.rgb(255, 159, 10)
        private val GRAY = Color.rgb(152, 152, 157)
        private val LIGHT = Color.rgb(209, 209, 214)
        private val FILL = Color.rgb(44, 44, 46)
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    // ---- window + views ----
    private var host: FrameLayout? = null
    private var card: IslandCard? = null
    private var header: FrameLayout? = null
    private var leftWing: FrameLayout? = null
    private var rightWing: FrameLayout? = null
    private var bodyHolder: FrameLayout? = null
    private var bg: GradientDrawable? = null
    private var lp: WindowManager.LayoutParams? = null
    private var radiusPx = 0f
    private var sizeAnim: ValueAnimator? = null
    private var curW = 0
    private var curH = 0

    // ---- geometry (px) ----
    private var geo = CameraGeo(0, 0, 0, 0, false)
    private var camGap = 0
    private var idleW = 0
    private var idleH = 0
    private var wingW = 0
    private var sidePad = 0
    private var expandedW = 0
    private var margin = 0

    // ---- ui state ----
    private var expanded = false
    private var userPage: Page? = null
    private var currentPage: Page? = null
    private var renderedPage: Page? = null
    private var renderedExpanded = false
    private var renderedVersion = -1
    private var contentVersion = 0
    private var lastAvail: List<Page> = emptyList()
    private var lastTouch = 0L
    private var downX = 0f
    private var downY = 0f
    private var suppressClick = false
    private var bodyClick: (() -> Unit)? = null

    // ---- dynamic view refs ----
    private var rightText: TextView? = null
    private var eqView: EqView? = null
    private var callSub: TextView? = null
    private var timerBig: TextView? = null
    private var timerBar: ThinSeek? = null
    private var mediaSeek: ThinSeek? = null
    private var mediaPosText: TextView? = null
    private var mediaDurText: TextView? = null
    private var playBtn: GlyphView? = null
    private var volSeek: ThinSeek? = null
    private var torchChip: Chip? = null

    // ---- call ----
    private var callNotif: IslandNotif? = null
    private var callState = TelephonyManager.CALL_STATE_IDLE
    private var callStartElapsed = 0L
    private var phoneListener: PhoneStateListener? = null

    // ---- notification pop ----
    private var notif: IslandNotif? = null
    private var notifUntil = 0L
    private var lastNotifKey = ""
    private var lastNotifTitle = ""
    private var lastNotifText = ""
    private var lastNotifAt = 0L

    // ---- focus timer ----
    private var timerActive = false
    private var timerRunning = false
    private var timerTotal = 0L
    private var timerLeft = 0L
    private var timerEndAt = 0L
    private var timerDoneUntil = 0L

    // ---- media ----
    private var mediaController: MediaController? = null
    private var mediaRegistered = false
    private var lastPlayingAt = 0L

    // ---- battery ----
    private var battery = 100
    private var plugged = false
    private var plugType = 0
    private var chargeEtaMs = -1L
    private var batteryUntil = 0L
    private var batteryLow = false
    private var lowShown = false
    private var lastBatSig = ""

    // ---- torch ----
    private var torchId: String? = null
    private var torchOn = false
    private var torchCb: CameraManager.TorchCallback? = null

    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    // ======================================================================================
    // Runnables / listeners
    // ======================================================================================

    private val ticker = object : Runnable {
        override fun run() {
            try {
                onTick()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val autoCollapse = Runnable {
        if (expanded && currentPage == Page.NOTIF) collapse()
    }

    private val longPress = Runnable {
        if (!expanded) {
            suppressClick = true
            haptic(null, true)
            expand(Page.HOME)
        }
    }

    private val renderLater = Runnable { render() }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) handleBattery(intent, false)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { relayout() }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bindMedia(list)
    }

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            onMediaChanged()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            onMediaChanged()
        }

        override fun onSessionDestroyed() {
            bindMedia(emptyList())
        }
    }

    // ======================================================================================
    // Service lifecycle
    // ======================================================================================

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        IslandBus.overlay = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        prefs = Prefs.get(this)
        prefs.edit().putBoolean(Prefs.RUNNING, true).apply()
        startAsForeground()

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(batteryReceiver, filter)
        }
        if (sticky != null) handleBattery(sticky, true)

        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        setupCalls()
        setupMedia()
        setupTorch()
        catchUpCalls()
        if (Settings.canDrawOverlays(this)) showIsland()
        handler.postDelayed(ticker, 1000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (host == null && Settings.canDrawOverlays(this)) showIsland()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post { relayout() }
    }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        sizeAnim?.cancel()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        try {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Exception) {
        }
        try {
            mediaController?.unregisterCallback(mediaCb)
        } catch (_: Exception) {
        }
        try {
            if (mediaRegistered) {
                val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
                msm.removeOnActiveSessionsChangedListener(sessionsListener)
            }
        } catch (_: Exception) {
        }
        try {
            val cb = torchCb
            if (cb != null) getSystemService(CameraManager::class.java).unregisterTorchCallback(cb)
        } catch (_: Exception) {
        }
        try {
            val l = phoneListener
            if (l != null) {
                val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                tm.listen(l, PhoneStateListener.LISTEN_NONE)
            }
        } catch (_: Exception) {
        }
        host?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        host = null
        card = null
        IslandBus.overlay = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Dynamic Island service", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island is active")
            .setContentText("Tap to open settings.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    // ======================================================================================
    // Geometry + window  (this is where the "under the camera" bug is fixed)
    // ======================================================================================

    private fun computeGeometry() {
        val dm = resources.displayMetrics
        geo = CameraGeometry.read(this)
        margin = dp(10)
        camGap = max(geo.width + dp(prefs.getInt(Prefs.ADJ_W, 0)), dp(12))
        val camH = max(geo.height + dp(prefs.getInt(Prefs.ADJ_H, 0)), dp(12))
        idleW = camGap + dp(8)
        idleH = camH + dp(8)
        wingW = dp(44)
        sidePad = dp(8)
        expandedW = min(dp(350), dm.widthPixels - dp(20))
    }

    /** Top of the card, in px from the physical top edge of the screen, centred on the camera. */
    private fun cardTop(): Int {
        val top = geo.centerY - idleH / 2 + dp(prefs.getInt(Prefs.OFF_Y, 0))
        return max(top, 0)
    }

    private fun windowX(): Int =
        geo.centerX - resources.displayMetrics.widthPixels / 2 + dp(prefs.getInt(Prefs.OFF_X, 0))

    private fun compactWidth(p: Page): Int =
        if (p == Page.HOME) idleW else camGap + 2 * (wingW + sidePad)

    private fun showIsland() {
        if (host != null) return
        computeGeometry()

        val h = FrameLayout(this)
        h.clipChildren = false
        h.clipToPadding = false
        h.setPadding(margin, margin, margin, margin)

        val c = IslandCard(this)
        val drawable = GradientDrawable()
        drawable.setColor(Color.BLACK)
        bg = drawable
        c.background = drawable
        c.clipToOutline = true
        c.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
            }
        }
        c.pivotY = idleH / 2f
        c.touchHook = { ev -> onCardTouch(ev) }

        val hdr = FrameLayout(this)
        hdr.setOnClickListener {
            if (!suppressClick) {
                haptic(hdr, false)
                if (expanded) collapse() else expand(null)
            }
        }
        val lw = FrameLayout(this)
        val rw = FrameLayout(this)
        val lwp = FrameLayout.LayoutParams(wingW, MATCH, Gravity.START or Gravity.TOP)
        lwp.leftMargin = sidePad
        val rwp = FrameLayout.LayoutParams(wingW, MATCH, Gravity.END or Gravity.TOP)
        rwp.rightMargin = sidePad
        hdr.addView(lw, lwp)
        hdr.addView(rw, rwp)
        c.addView(hdr, FrameLayout.LayoutParams(MATCH, idleH, Gravity.TOP))

        val holder = FrameLayout(this)
        holder.setOnClickListener { bodyClick?.invoke() }
        val hp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP)
        hp.topMargin = idleH
        c.addView(holder, hp)

        h.addView(c, FrameLayout.LayoutParams(idleW, idleH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        h.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && expanded) collapse()
            false
        }

        val params = WindowManager.LayoutParams(
            idleW + 2 * margin,
            idleH + 2 * margin,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.x = windowX()
        params.y = cardTop() - margin
        params.title = "DynamicIsland"
        // THE FIX: let this window extend into the camera cutout instead of being pushed below it.
        if (Build.VERSION.SDK_INT >= 30) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            params.fitInsetsTypes = 0
        } else if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        try {
            wm.addView(h, params)
        } catch (_: Exception) {
            return
        }
        host = h
        card = c
        header = hdr
        leftWing = lw
        rightWing = rw
        bodyHolder = holder
        lp = params
        curW = 0
        curH = 0
        applyCard(idleW, idleH)
        renderedVersion = -1
        render(false)
        relayout()
    }

    /** Re-reads geometry/prefs and repositions everything (rotation, slider moves, density change). */
    private fun relayout() {
        val h = host ?: return
        val l = lp ?: return
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (landscape) {
            h.visibility = View.GONE
            l.flags = l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try {
                wm.updateViewLayout(h, l)
            } catch (_: Exception) {
            }
            return
        }
        h.visibility = View.VISIBLE
        l.flags = l.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        computeGeometry()
        l.x = windowX()
        l.y = cardTop() - margin
        header?.let {
            val p = it.layoutParams as FrameLayout.LayoutParams
            p.height = idleH
            it.layoutParams = p
        }
        bodyHolder?.let {
            val p = it.layoutParams as FrameLayout.LayoutParams
            p.topMargin = idleH
            it.layoutParams = p
        }
        card?.pivotY = idleH / 2f
        renderedVersion = -1
        render(false)
    }

    private fun setWindow(cardW: Int, cardH: Int, extra: Int) {
        val l = lp ?: return
        val h = host ?: return
        l.width = cardW + 2 * margin + 2 * extra
        l.height = cardH + 2 * margin + extra
        try {
            wm.updateViewLayout(h, l)
        } catch (_: Exception) {
        }
    }

    private fun applyCard(w: Int, h: Int) {
        val c = card ?: return
        val p = c.layoutParams as FrameLayout.LayoutParams
        p.width = w
        p.height = h
        c.layoutParams = p
        curW = w
        curH = h
        radiusPx = min(h / 2f, dp(30).toFloat())
        bg?.cornerRadius = radiusPx
        c.invalidateOutline()
    }

    private fun animateTo(tw: Int, th: Int, animate: Boolean) {
        sizeAnim?.cancel()
        if (!animate || curW == 0) {
            applyCard(tw, th)
            setWindow(tw, th, 0)
            return
        }
        val sw = curW
        val sh = curH
        if (sw == tw && sh == th) {
            setWindow(tw, th, 0)
            return
        }
        val growing = th > sh || tw > sw
        setWindow(max(sw, tw), max(sh, th), dp(24))
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (growing) 420L else 300L
        a.interpolator = if (growing) OvershootInterpolator(0.7f) else DecelerateInterpolator(1.5f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            applyCard((sw + (tw - sw) * f).toInt(), (sh + (th - sh) * f).toInt())
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) {
                    applyCard(tw, th)
                    setWindow(tw, th, 0)
                }
            }
        })
        sizeAnim = a
        a.start()
    }

    // ======================================================================================
    // Rendering
    // ======================================================================================

    private fun available(): List<Page> {
        val now = SystemClock.elapsedRealtime()
        val l = ArrayList<Page>(6)
        if (callNotif != null || callState != TelephonyManager.CALL_STATE_IDLE) l.add(Page.CALL)
        if (notif != null && now < notifUntil) l.add(Page.NOTIF)
        if (timerActive || now < timerDoneUntil) l.add(Page.TIMER)
        if (mediaVisible()) l.add(Page.MEDIA)
        if (now < batteryUntil) l.add(Page.CHARGE)
        l.add(Page.HOME)
        return l
    }

    private fun seekBusy(): Boolean = volSeek?.dragging == true || mediaSeek?.dragging == true

    private fun render(animate: Boolean = true) {
        val c = card ?: return
        val holder = bodyHolder ?: return
        if (seekBusy()) {
            handler.removeCallbacks(renderLater)
            handler.postDelayed(renderLater, 250)
            return
        }
        val av = available()
        val top = av.first()
        val wanted = userPage
        if (wanted != null && !av.contains(wanted)) userPage = null
        val shown = if (expanded) (userPage ?: top) else top
        val pageChanged = shown != renderedPage
        val expandedChanged = expanded != renderedExpanded
        val rebuild = pageChanged || expandedChanged || contentVersion != renderedVersion
        currentPage = shown
        lastAvail = av

        if (rebuild) {
            renderedPage = shown
            renderedExpanded = expanded
            renderedVersion = contentVersion
            buildWings(shown, animate && pageChanged)
            holder.animate().cancel()
            if (expanded) {
                val body = buildBody(shown)
                holder.removeAllViews()
                holder.addView(body)
                if (animate && (expandedChanged || pageChanged)) {
                    holder.alpha = 0f
                    holder.animate().alpha(1f).setStartDelay(100).setDuration(220).start()
                } else {
                    holder.alpha = 1f
                }
            } else {
                bodyClick = null
                clearBodyRefs()
                holder.animate().alpha(0f).setStartDelay(0).setDuration(110).withEndAction {
                    if (!expanded) holder.removeAllViews()
                }.start()
            }
        }

        val tw: Int
        val th: Int
        if (expanded && holder.childCount > 0) {
            val bodyView = holder.getChildAt(0)
            bodyView.measure(
                View.MeasureSpec.makeMeasureSpec(expandedW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            tw = expandedW
            th = idleH + bodyView.measuredHeight
        } else {
            tw = compactWidth(top)
            th = idleH
        }
        animateTo(tw, th, animate)

        // Idle pill is invisible (blends with the camera); calibration mode makes it visible.
        val cal = prefs.getBoolean(Prefs.CALIBRATION, false)
        val hide = !expanded && top == Page.HOME && prefs.getBoolean(Prefs.HIDE_IDLE, true) && !cal
        bg?.setColor(if (cal) Color.rgb(46, 46, 54) else Color.BLACK)
        bg?.setStroke(if (cal) dp(1) else 0, ACCENT)
        val targetAlpha = if (hide) 0f else 1f
        if (c.alpha != targetAlpha) {
            val oa = ObjectAnimator.ofFloat(c, View.ALPHA, targetAlpha)
            oa.duration = if (animate) 180L else 0L
            oa.start()
        }
        refreshDynamic()
    }

    private fun clearBodyRefs() {
        callSub = null
        timerBig = null
        timerBar = null
        mediaSeek = null
        mediaPosText = null
        mediaDurText = null
        playBtn = null
        volSeek = null
        torchChip = null
    }

    private fun wingParams() = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)

    private fun wingText(color: Int): TextView {
        val t = tv("", 12f, color, true)
        t.maxLines = 1
        return t
    }

    private fun buildWings(p: Page, fade: Boolean) {
        val lw = leftWing ?: return
        val rw = rightWing ?: return
        lw.removeAllViews()
        rw.removeAllViews()
        rightText = null
        eqView = null
        when (p) {
            Page.CALL -> {
                lw.addView(GlyphView(this, Glyph.PHONE, GREEN), wingParams())
                val t = wingText(GREEN)
                rightText = t
                rw.addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            }
            Page.NOTIF -> {
                val n = notif
                if (n != null) lw.addView(roundImage(n.icon, dp(24)), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            }
            Page.TIMER -> {
                lw.addView(GlyphView(this, Glyph.TIMER, ORANGE), wingParams())
                val t = wingText(ORANGE)
                rightText = t
                rw.addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            }
            Page.MEDIA -> {
                lw.addView(artworkView(dp(24)), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                val eq = EqView(this)
                eq.playing = isPlaying()
                eqView = eq
                rw.addView(eq, FrameLayout.LayoutParams(dp(20), dp(18), Gravity.CENTER))
            }
            Page.CHARGE -> {
                val low = batteryLow && !plugged
                lw.addView(GlyphView(this, Glyph.BOLT, if (low) RED else GREEN), wingParams())
                val t = wingText(if (low) RED else GREEN)
                rightText = t
                rw.addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            }
            Page.HOME -> {
            }
        }
        if (fade) {
            lw.alpha = 0f
            rw.alpha = 0f
            lw.animate().alpha(1f).setDuration(180).start()
            rw.animate().alpha(1f).setDuration(180).start()
        } else {
            lw.alpha = 1f
            rw.alpha = 1f
        }
    }

    private fun buildBody(p: Page): View {
        bodyClick = null
        clearBodyRefs()
        return when (p) {
            Page.CALL -> callBody()
            Page.NOTIF -> notifBody()
            Page.TIMER -> timerBody()
            Page.MEDIA -> mediaBody()
            Page.CHARGE -> chargeBody()
            Page.HOME -> homeBody()
        }
    }

    /** Updates the ticking bits (timers, progress) without rebuilding any views. */
    private fun refreshDynamic() {
        when (renderedPage) {
            Page.CALL -> {
                rightText?.text = callShort()
                callSub?.text = callSubtitle()
            }
            Page.TIMER -> {
                val left = timerLeftMs()
                val label = if (timerActive) fmt(left) else "Done"
                rightText?.text = label
                timerBig?.text = label
                if (timerTotal > 0) timerBar?.progress = left.toFloat() / timerTotal.toFloat()
            }
            Page.MEDIA -> {
                val md = mediaController?.metadata
                val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                val pos = mediaPositionMs()
                if (dur > 0) {
                    if (mediaSeek?.dragging != true) mediaSeek?.progress = pos.toFloat() / dur.toFloat()
                    mediaPosText?.text = fmt(pos)
                    mediaDurText?.text = fmt(dur)
                }
                eqView?.playing = isPlaying()
                playBtn?.set(if (isPlaying()) Glyph.PAUSE else Glyph.PLAY, Color.WHITE)
            }
            Page.CHARGE -> rightText?.text = "$battery%"
            else -> {
            }
        }
    }

    // ======================================================================================
    // Page bodies
    // ======================================================================================

    private fun newBody(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.setPadding(dp(20), dp(2), dp(20), dp(18))
        b.layoutParams = FrameLayout.LayoutParams(MATCH, WRAP)
        return b
    }

    private fun lpv(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(left, top, right, bottom)
        return p
    }

    private fun mediaBody(): View {
        val body = newBody()
        val mc = mediaController
        val md = mc?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Nothing playing"
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(artworkView(dp(58)), lpv(dp(58), dp(58)))
        val labels = LinearLayout(this)
        labels.orientation = LinearLayout.VERTICAL
        val t1 = tv(title, 16f, Color.WHITE, true)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val t2 = tv(artist, 13f, GRAY, false)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        labels.addView(t1)
        labels.addView(t2)
        row.addView(labels, lpv(0, WRAP, dp(12)).also { it.weight = 1f })
        body.addView(row)

        val seek = ThinSeek(this)
        seek.interactive = dur > 0
        seek.onCommit = { p -> mediaController?.transportControls?.seekTo((p * dur).toLong()) }
        mediaSeek = seek
        body.addView(seek, lpv(MATCH, dp(26), 0, dp(10)))

        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        val pos = tv("0:00", 10f, GRAY, false)
        val total = tv(if (dur > 0) fmt(dur) else "", 10f, GRAY, false)
        mediaPosText = pos
        mediaDurText = total
        times.addView(pos, lpv(0, WRAP).also { it.weight = 1f })
        times.addView(total)
        body.addView(times)

        val ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.gravity = Gravity.CENTER
        ctrl.addView(glyphButton(Glyph.PREV) { mediaController?.transportControls?.skipToPrevious() }, lpv(dp(50), dp(50)))
        val play = glyphButton(if (isPlaying()) Glyph.PAUSE else Glyph.PLAY) {
            if (isPlaying()) mediaController?.transportControls?.pause() else mediaController?.transportControls?.play()
        }
        playBtn = play
        ctrl.addView(play, lpv(dp(58), dp(58), dp(18), 0, dp(18), 0))
        ctrl.addView(glyphButton(Glyph.NEXT) { mediaController?.transportControls?.skipToNext() }, lpv(dp(50), dp(50)))
        body.addView(ctrl, lpv(MATCH, WRAP, 0, dp(4)))
        body.addView(volumeRow(), lpv(MATCH, dp(28), 0, dp(6)))

        bodyClick = {
            collapse()
            try {
                mediaController?.sessionActivity?.send()
            } catch (_: Exception) {
            }
        }
        return body
    }

    private fun notifBody(): View {
        val body = newBody()
        val n = notif
        if (n == null) {
            body.addView(tv("No notification", 14f, GRAY, false))
            return body
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(roundImage(n.icon, dp(44)), lpv(dp(44), dp(44)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val app = tv(n.appName.uppercase(), 10f, GRAY, true)
        app.maxLines = 1
        app.letterSpacing = 0.06f
        col.addView(app)
        val title = tv(n.title, 15f, Color.WHITE, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        if (n.text.isNotBlank()) {
            val text = tv(n.text, 13f, LIGHT, false)
            text.maxLines = 3
            text.ellipsize = TextUtils.TruncateAt.END
            col.addView(text)
        }
        row.addView(col, lpv(0, WRAP, dp(12)).also { it.weight = 1f })
        body.addView(row)

        val acts = n.actions.take(2)
        if (acts.isNotEmpty()) {
            val ar = LinearLayout(this)
            ar.orientation = LinearLayout.HORIZONTAL
            ar.gravity = Gravity.END
            for (a in acts) {
                ar.addView(pill(a.title, FILL, Color.WHITE) { fire(a.intent) }, lpv(WRAP, WRAP, dp(8)))
            }
            body.addView(ar, lpv(MATCH, WRAP, 0, dp(12)))
        }
        bodyClick = { openPending(n.contentIntent) }
        return body
    }

    private fun callBody(): View {
        val body = newBody()
        val n = callNotif
        val name = n?.title?.takeIf { it.isNotBlank() } ?: "Phone call"
        val incoming = callIncoming()

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val avatar = TextView(this)
        avatar.text = name.trim().take(1).uppercase()
        avatar.textSize = 20f
        avatar.setTextColor(Color.WHITE)
        avatar.gravity = Gravity.CENTER
        avatar.typeface = Typeface.DEFAULT_BOLD
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(FILL)
        avatar.background = circle
        top.addView(avatar, lpv(dp(52), dp(52)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val nameView = tv(name, 19f, Color.WHITE, true)
        nameView.maxLines = 1
        nameView.ellipsize = TextUtils.TruncateAt.END
        col.addView(nameView)
        val sub = tv(callSubtitle(), 13f, GREEN, false)
        callSub = sub
        col.addView(sub, lpv(WRAP, WRAP, 0, dp(3)))
        top.addView(col, lpv(0, WRAP, dp(14)).also { it.weight = 1f })
        body.addView(top)

        val acts = (n?.actions ?: emptyList()).take(2)
        if (acts.isNotEmpty()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            // negative (decline / hang up) first, positive (answer) last
            val ordered = acts.withIndex().sortedBy { (i, a) -> actionRank(a.title, i, incoming) }
            for ((i, iv) in ordered.withIndex()) {
                val a = iv.value
                val rank = actionRank(a.title, iv.index, incoming)
                val color = when {
                    rank == 0 -> RED
                    rank == 2 -> GREEN
                    else -> FILL
                }
                row.addView(pill(a.title, color, Color.WHITE) { fire(a.intent) }, lpv(0, WRAP, if (i == 0) 0 else dp(10)).also { it.weight = 1f })
            }
            body.addView(row, lpv(MATCH, WRAP, 0, dp(16)))
        }
        return body
    }

    private fun actionRank(title: String, index: Int, incoming: Boolean): Int {
        val t = title.lowercase()
        if (t.contains("answer") || t.contains("accept") || t.contains("pick")) return 2
        if (t.contains("decline") || t.contains("reject") || t.contains("hang") || t.contains("end") || t.contains("dismiss")) return 0
        // Unknown language: assume first = decline, second = answer for incoming; single action = hang up.
        return if (incoming) (if (index == 0) 0 else 2) else 1
    }

    private fun timerBody(): View {
        val body = newBody()
        if (!timerActive) {
            val t = tv("Time's up", 26f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            body.addView(t, lpv(MATCH, WRAP))
            val s = tv("Nice work. Take a short break.", 13f, GRAY, false)
            s.gravity = Gravity.CENTER
            body.addView(s, lpv(MATCH, WRAP, 0, dp(4)))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(pill("Break 5 min", FILL, Color.WHITE) { startTimer(5 * 60_000L) }, lpv(0, WRAP).also { it.weight = 1f })
            row.addView(pill("Focus 25 min", ORANGE, Color.BLACK) { startTimer(25 * 60_000L) }, lpv(0, WRAP, dp(10)).also { it.weight = 1f })
            body.addView(row, lpv(MATCH, WRAP, 0, dp(16)))
            return body
        }
        val big = tv(fmt(timerLeftMs()), 44f, Color.WHITE, false)
        big.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        big.gravity = Gravity.CENTER
        timerBig = big
        body.addView(big, lpv(MATCH, WRAP))
        val bar = ThinSeek(this)
        bar.interactive = false
        bar.fill = ORANGE
        timerBar = bar
        body.addView(bar, lpv(MATCH, dp(22), 0, dp(8)))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(pill(if (timerRunning) "Pause" else "Resume", FILL, Color.WHITE) {
            if (timerRunning) pauseTimer() else resumeTimer()
            bump()
        }, lpv(0, WRAP).also { it.weight = 1f })
        row.addView(pill("+5 min", FILL, Color.WHITE) {
            timerLeft = timerLeftMs() + 5 * 60_000L
            timerTotal += 5 * 60_000L
            if (timerRunning) timerEndAt = SystemClock.elapsedRealtime() + timerLeft
            bump()
        }, lpv(0, WRAP, dp(8)).also { it.weight = 1f })
        row.addView(pill("Stop", RED, Color.WHITE) {
            stopTimer()
            userPage = null
            bump()
        }, lpv(0, WRAP, dp(8)).also { it.weight = 1f })
        body.addView(row, lpv(MATCH, WRAP, 0, dp(14)))
        return body
    }

    private fun chargeBody(): View {
        val body = newBody()
        val low = batteryLow && !plugged
        val big = tv("$battery%", 44f, Color.WHITE, false)
        big.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        big.gravity = Gravity.CENTER
        body.addView(big, lpv(MATCH, WRAP))
        val sub = if (low) {
            "Battery low. Plug in soon."
        } else {
            val kind = when (plugType) {
                BatteryManager.BATTERY_PLUGGED_USB -> "Charging via USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Charging wirelessly"
                else -> "Charging"
            }
            if (chargeEtaMs > 0) kind + " \u00B7 " + etaText(chargeEtaMs) + " to full" else kind
        }
        val s = tv(sub, 13f, if (low) RED else GREEN, false)
        s.gravity = Gravity.CENTER
        body.addView(s, lpv(MATCH, WRAP, 0, dp(2)))
        val bar = ThinSeek(this)
        bar.interactive = false
        bar.fill = if (low) RED else GREEN
        bar.progress = battery / 100f
        body.addView(bar, lpv(MATCH, dp(22), 0, dp(10)))
        return body
    }

    private fun homeBody(): View {
        val body = newBody()
        val state = if (plugged) (if (battery >= 100) "Fully charged" else "Charging") else "On battery"
        body.addView(tv("Battery $battery% \u00B7 $state", 12f, GRAY, false))

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val torch = makeChip(Glyph.TORCH, "Torch") { toggleTorch() }
        torch.setActive(torchOn)
        torchChip = torch
        chips.addView(torch.view, lpv(0, WRAP).also { it.weight = 1f })
        chips.addView(makeChip(Glyph.TIMER, "Focus 25") { startFocus(25) }.view, lpv(0, WRAP).also { it.weight = 1f })
        chips.addView(makeChip(Glyph.TIMER, "Study 50") { startFocus(50) }.view, lpv(0, WRAP).also { it.weight = 1f })
        chips.addView(makeChip(Glyph.GEAR, "Settings") { openSettings() }.view, lpv(0, WRAP).also { it.weight = 1f })
        body.addView(chips, lpv(MATCH, WRAP, 0, dp(14)))
        body.addView(volumeRow(), lpv(MATCH, dp(28), 0, dp(14)))
        return body
    }

    private fun startFocus(minutes: Int) {
        startTimer(minutes * 60_000L)
        userPage = Page.TIMER
        bump()
    }

    // ======================================================================================
    // Small UI helpers
    // ======================================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.includeFontPadding = false
        return t
    }

    private fun pill(label: String, bgColor: Int, fg: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 13f
        t.setTextColor(fg)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(16), dp(10), dp(16), dp(10))
        val d = GradientDrawable()
        d.setColor(bgColor)
        d.cornerRadius = dp(22).toFloat()
        t.background = d
        t.setOnClickListener {
            haptic(t, false)
            onClick()
        }
        return t
    }

    private fun glyphButton(g: Glyph, onClick: () -> Unit): GlyphView {
        val v = GlyphView(this, g, Color.WHITE)
        v.setOnClickListener {
            haptic(v, false)
            onClick()
        }
        return v
    }

    private fun makeChip(g: Glyph, label: String, onClick: () -> Unit): Chip {
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(FILL)
        val holder = FrameLayout(this)
        holder.background = circle
        val gv = GlyphView(this, g, Color.WHITE)
        holder.addView(gv, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(holder, lpv(dp(54), dp(54)))
        col.addView(tv(label, 10f, GRAY, false), lpv(WRAP, WRAP, 0, dp(6)))
        col.setOnClickListener {
            haptic(col, false)
            onClick()
        }
        return Chip(col, gv, circle)
    }

    private fun volumeRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv("VOL", 9f, GRAY, true), lpv(WRAP, WRAP, 0, 0, dp(10)))
        val maxV = max(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 1)
        val seek = ThinSeek(this)
        seek.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV
        seek.onChange = { p ->
            val v = (p * maxV + 0.5f).toInt().coerceIn(0, maxV)
            try {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
            } catch (_: Exception) {
            }
        }
        volSeek = seek
        row.addView(seek, lpv(0, dp(28)).also { it.weight = 1f })
        return row
    }

    private fun roundOutline(radius: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius.toFloat())
        }
    }

    private fun roundImage(d: Drawable?, size: Int): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(FILL)
        iv.clipToOutline = true
        iv.outlineProvider = roundOutline(size / 4)
        if (d != null) iv.setImageDrawable(d)
        return iv
    }

    private fun mediaArt(): Bitmap? {
        val md = mediaController?.metadata ?: return null
        return md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    }

    private fun artworkView(size: Int): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(FILL)
        iv.clipToOutline = true
        iv.outlineProvider = roundOutline(size / 4)
        val bmp = mediaArt()
        if (bmp != null) {
            iv.setImageBitmap(bmp)
        } else {
            try {
                val pkg = mediaController?.packageName
                if (pkg != null) iv.setImageDrawable(packageManager.getApplicationIcon(pkg))
            } catch (_: Exception) {
            }
        }
        return iv
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun etaText(ms: Long): String {
        val m = ms / 60000
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }

    private fun haptic(v: View?, strong: Boolean) {
        if (!prefs.getBoolean(Prefs.HAPTICS, true)) return
        try {
            (v ?: card)?.performHapticFeedback(
                if (strong) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.CLOCK_TICK
            )
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        if (!prefs.getBoolean(Prefs.HAPTICS, true)) return
        try {
            val vib = getSystemService(VIBRATOR_SERVICE) as Vibrator
            val pattern = longArrayOf(0, 200, 120, 200, 120, 400)
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pattern, -1))
            else vib.vibrate(pattern, -1)
        } catch (_: Exception) {
        }
    }

    private fun pulse() {
        val c = card ?: return
        val sx = if (expanded) 1.03f else 1.08f
        val sy = if (expanded) 1.03f else 1.14f
        c.animate().cancel()
        c.animate().scaleX(sx).scaleY(sy).setDuration(120).setInterpolator(DecelerateInterpolator())
            .withEndAction {
                c.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(OvershootInterpolator(2.5f)).start()
            }.start()
    }

    private fun bump() {
        contentVersion++
        render()
    }

    // ======================================================================================
    // Interaction
    // ======================================================================================

    private fun expand(page: Page?) {
        expanded = true
        userPage = page
        handler.removeCallbacks(autoCollapse)
        render()
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false
        userPage = null
        handler.removeCallbacks(autoCollapse)
        render()
    }

    private fun onUserTouch() {
        lastTouch = SystemClock.elapsedRealtime()
        handler.removeCallbacks(autoCollapse)
        if (currentPage == Page.NOTIF) notifUntil = max(notifUntil, lastTouch + 10_000L)
    }

    private fun onCardTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                onUserTouch()
                downX = ev.x
                downY = ev.y
                suppressClick = false
                handler.removeCallbacks(longPress)
                handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) handler.removeCallbacks(longPress)
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPress)
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (abs(dy) > dp(36) && abs(dy) > abs(dx) * 1.5f) {
                    // swipe up closes, swipe down opens
                    if (dy < 0 && expanded) {
                        suppressClick = true
                        collapse()
                    } else if (dy > 0 && !expanded) {
                        suppressClick = true
                        expand(null)
                    }
                } else if (expanded && downY < idleH && abs(dx) > dp(56) && abs(dx) > abs(dy) * 1.5f) {
                    cyclePage(if (dx < 0) 1 else -1)
                }
            }
            MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
        }
    }

    private fun cyclePage(dir: Int) {
        val av = available()
        if (av.size < 2) return
        val cur = (currentPage?.let { av.indexOf(it) } ?: 0).coerceAtLeast(0)
        userPage = av[(cur + dir + av.size) % av.size]
        suppressClick = true
        haptic(null, false)
        render()
    }

    private fun openPending(pi: PendingIntent?) {
        collapse()
        if (pi == null) return
        try {
            pi.send()
        } catch (_: Exception) {
        }
    }

    private fun fire(pi: PendingIntent) {
        try {
            pi.send()
        } catch (_: Exception) {
        }
        collapse()
    }

    private fun openSettings() {
        collapse()
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    // ======================================================================================
    // Notifications + calls
    // ======================================================================================

    fun onListenerConnected() {
        setupMedia()
        catchUpCalls()
        bump()
    }

    private fun catchUpCalls() {
        val l = IslandNotificationListener.instance ?: return
        val c = l.activeCall() ?: return
        callNotif = c
    }

    fun onIslandNotification(n: IslandNotif) {
        if (n.isCall) {
            val isNew = callNotif == null || callNotif?.key != n.key
            callNotif = n
            if (n.incoming && isNew) {
                haptic(null, true)
                expanded = true
                userPage = Page.CALL
            }
            bump()
            return
        }
        if (!prefs.getBoolean(Prefs.NOTIFS, true)) return
        val now = SystemClock.elapsedRealtime()
        if (n.key == lastNotifKey && n.title == lastNotifTitle && n.text == lastNotifText && now - lastNotifAt < 2500) return
        lastNotifKey = n.key
        lastNotifTitle = n.title
        lastNotifText = n.text
        lastNotifAt = now
        notif = n
        notifUntil = now + 5500
        haptic(null, false)
        val inCall = callNotif != null || callState != TelephonyManager.CALL_STATE_IDLE
        val busy = expanded && now - lastTouch < 3000 && currentPage != Page.NOTIF
        if (!busy && !inCall) {
            expanded = true
            userPage = Page.NOTIF
            handler.removeCallbacks(autoCollapse)
            handler.postDelayed(autoCollapse, 5000)
        }
        contentVersion++
        render()
        pulse()
    }

    fun onIslandNotificationRemoved(key: String) {
        var changed = false
        if (callNotif?.key == key) {
            callNotif = null
            if (callState == TelephonyManager.CALL_STATE_IDLE) callStartElapsed = 0L
            changed = true
        }
        if (notif?.key == key) {
            notif = null
            notifUntil = 0L
            changed = true
        }
        if (changed) bump()
    }

    @Suppress("DEPRECATION")
    private fun setupCalls() {
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val l = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    handleCallState(state)
                }
            }
            phoneListener = l
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        } catch (_: Exception) {
        }
    }

    private fun handleCallState(state: Int) {
        val prev = callState
        callState = state
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                haptic(null, true)
                expanded = true
                userPage = Page.CALL
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (callStartElapsed == 0L) callStartElapsed = SystemClock.elapsedRealtime()
                if (prev == TelephonyManager.CALL_STATE_RINGING && expanded && currentPage == Page.CALL) {
                    expanded = false
                    userPage = null
                }
            }
            else -> {
                callStartElapsed = 0L
                callNotif = null
                if (expanded && currentPage == Page.CALL) {
                    expanded = false
                    userPage = null
                }
            }
        }
        bump()
    }

    private fun callIncoming(): Boolean = when (callState) {
        TelephonyManager.CALL_STATE_RINGING -> true
        TelephonyManager.CALL_STATE_OFFHOOK -> false
        else -> callNotif?.incoming == true
    }

    private fun callElapsedMs(): Long {
        val n = callNotif
        return when {
            callStartElapsed > 0L -> SystemClock.elapsedRealtime() - callStartElapsed
            n != null && n.showsChronometer -> (System.currentTimeMillis() - n.whenMs).coerceAtLeast(0L)
            else -> 0L
        }
    }

    private fun callShort(): String = if (callIncoming()) "Ringing" else fmt(callElapsedMs())

    private fun callSubtitle(): String =
        if (callIncoming()) "Incoming call" else "Ongoing call \u00B7 " + fmt(callElapsedMs())

    // ======================================================================================
    // Media
    // ======================================================================================

    private fun setupMedia() {
        if (mediaRegistered) return
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, IslandNotificationListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            mediaRegistered = true
            bindMedia(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {
            // Notification access not granted yet; retried when the listener connects.
        } catch (_: Exception) {
        }
    }

    private fun bindMedia(list: List<MediaController>?) {
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (pick != null && pick.sessionToken == mediaController?.sessionToken) {
            onMediaChanged()
            return
        }
        try {
            mediaController?.unregisterCallback(mediaCb)
        } catch (_: Exception) {
        }
        mediaController = pick
        try {
            pick?.registerCallback(mediaCb)
        } catch (_: Exception) {
        }
        onMediaChanged()
    }

    private fun onMediaChanged() {
        if (isPlaying()) lastPlayingAt = SystemClock.elapsedRealtime()
        bump()
    }

    private fun isPlaying(): Boolean = mediaController?.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun mediaVisible(): Boolean {
        val mc = mediaController ?: return false
        val st = mc.playbackState?.state ?: return false
        val md = mc.metadata
        val hasTitle = !md?.getString(MediaMetadata.METADATA_KEY_TITLE).isNullOrBlank() ||
            !md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE).isNullOrBlank()
        if (!hasTitle) return false
        return when (st) {
            PlaybackState.STATE_PLAYING, PlaybackState.STATE_BUFFERING -> true
            PlaybackState.STATE_PAUSED ->
                SystemClock.elapsedRealtime() - lastPlayingAt < 10_000L || (expanded && currentPage == Page.MEDIA)
            else -> false
        }
    }

    private fun mediaPositionMs(): Long {
        val st = mediaController?.playbackState ?: return 0L
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING) {
            val delta = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
            pos += (delta * st.playbackSpeed).toLong()
        }
        return pos.coerceAtLeast(0L)
    }

    // ======================================================================================
    // Battery
    // ======================================================================================

    private fun handleBattery(i: Intent, initial: Boolean) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level >= 0 && scale > 0) battery = level * 100 / scale
        val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val nowPlugged = plug != 0
        val wasPlugged = plugged
        plugged = nowPlugged
        plugType = plug
        val now = SystemClock.elapsedRealtime()
        if (!initial) {
            if (nowPlugged && !wasPlugged && prefs.getBoolean(Prefs.CHARGING, true)) {
                batteryLow = false
                batteryUntil = now + 4500
                haptic(null, false)
                pulse()
            } else if (!nowPlugged && battery <= 15 && !lowShown) {
                lowShown = true
                batteryLow = true
                batteryUntil = now + 5000
                haptic(null, true)
                pulse()
            }
        }
        if (battery > 20 || nowPlugged) lowShown = false
        chargeEtaMs = if (nowPlugged) {
            try {
                (getSystemService(BATTERY_SERVICE) as BatteryManager).computeChargeTimeRemaining()
            } catch (_: Throwable) {
                -1L
            }
        } else -1L
        val sig = "$battery/$nowPlugged/$batteryUntil"
        if (sig != lastBatSig) {
            lastBatSig = sig
            bump()
        }
    }

    // ======================================================================================
    // Focus timer
    // ======================================================================================

    private fun startTimer(ms: Long) {
        timerTotal = ms
        timerLeft = ms
        timerRunning = true
        timerActive = true
        timerEndAt = SystemClock.elapsedRealtime() + ms
        timerDoneUntil = 0L
        userPage = Page.TIMER
        bump()
    }

    private fun timerLeftMs(): Long =
        if (timerRunning) max(0L, timerEndAt - SystemClock.elapsedRealtime()) else timerLeft

    private fun pauseTimer() {
        timerLeft = timerLeftMs()
        timerRunning = false
    }

    private fun resumeTimer() {
        timerEndAt = SystemClock.elapsedRealtime() + timerLeft
        timerRunning = true
    }

    private fun stopTimer() {
        timerActive = false
        timerRunning = false
        timerDoneUntil = 0L
    }

    private fun checkTimer() {
        if (timerActive && timerRunning && timerLeftMs() <= 0L) {
            timerActive = false
            timerRunning = false
            timerDoneUntil = SystemClock.elapsedRealtime() + 20_000L
            buzz()
            expanded = true
            userPage = Page.TIMER
            contentVersion++
            render()
            pulse()
        }
    }

    // ======================================================================================
    // Torch
    // ======================================================================================

    private fun setupTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            torchId = cm.cameraIdList.firstOrNull { id ->
                val ch = cm.getCameraCharacteristics(id)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) {
                        torchOn = enabled
                        torchChip?.setActive(enabled)
                    }
                }
            }
            torchCb = cb
            cm.registerTorchCallback(cb, handler)
        } catch (_: Exception) {
        }
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            getSystemService(CameraManager::class.java).setTorchMode(id, !torchOn)
        } catch (_: Exception) {
        }
    }

    // ======================================================================================
    // Tick + demo helpers for the settings screen
    // ======================================================================================

    private fun onTick() {
        checkTimer()
        val av = available()
        if (av != lastAvail) {
            val cur = currentPage
            if (expanded && cur != null && cur != Page.HOME && !av.contains(cur) && !seekBusy()) {
                collapse()
            } else {
                contentVersion++
                render()
            }
        }
        refreshDynamic()
    }

    fun demoNotification() {
        val icon = try {
            packageManager.getApplicationIcon(packageName)
        } catch (_: Exception) {
            null
        }
        val open = PendingIntent.getActivity(
            this, 7, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        onIslandNotification(
            IslandNotif(
                key = "demo-" + System.currentTimeMillis(),
                pkg = packageName,
                appName = "Dynamic Island",
                title = "Hello from your island",
                text = "Notifications appear here. Tap to open settings, swipe up to dismiss.",
                icon = icon,
                contentIntent = open,
                actions = emptyList(),
                isCall = false,
                incoming = false,
                whenMs = System.currentTimeMillis(),
                showsChronometer = false
            )
        )
    }

    fun demoCharging() {
        batteryLow = false
        batteryUntil = SystemClock.elapsedRealtime() + 4500
        pulse()
        bump()
    }
}
