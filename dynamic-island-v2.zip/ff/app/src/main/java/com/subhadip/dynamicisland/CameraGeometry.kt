package com.subhadip.dynamicisland

import android.content.Context
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import android.view.DisplayCutout
import android.view.WindowManager

/** Where the front camera hole is, in pixels. */
class CameraGeo(
    val centerX: Int,
    val centerY: Int,
    val width: Int,
    val height: Int,
    val detected: Boolean
)

object CameraGeometry {
    /**
     * Asks Android where the camera cutout is. Falls back to a sensible centred default
     * (the sliders in the app then let the user fine-tune it).
     */
    fun read(context: Context): CameraGeo {
        val dm = context.resources.displayMetrics
        val density = dm.density
        var rect: Rect? = null
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val display = context.getSystemService(DisplayManager::class.java)
                    ?.getDisplay(Display.DEFAULT_DISPLAY)
                rect = topRect(display?.cutout)
                if (rect == null) {
                    val wm = context.getSystemService(WindowManager::class.java)
                    rect = topRect(wm?.maximumWindowMetrics?.windowInsets?.displayCutout)
                }
            }
        } catch (_: Throwable) {
        }
        val r = rect
        return if (r != null && r.width() > 0 && r.height() > 0) {
            CameraGeo(r.centerX(), r.centerY(), r.width(), r.height(), true)
        } else {
            val size = (24 * density).toInt()
            CameraGeo(dm.widthPixels / 2, (20 * density).toInt(), size, size, false)
        }
    }

    private fun topRect(cutout: DisplayCutout?): Rect? {
        if (cutout == null) return null
        return cutout.boundingRects
            .filter { it.width() > 0 && it.height() > 0 }
            .minByOrNull { it.top }
    }
}
