package com.subhadip.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(18, 20, 28)
    private val accent = Color.rgb(89, 230, 210)
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var camInfo: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(44))
        scroll.addView(root)

        val title = TextView(this)
        title.text = "DYNAMIC ISLAND"
        title.textSize = 25f
        title.setTextColor(Color.WHITE)
        title.letterSpacing = .14f
        title.gravity = Gravity.CENTER
        root.addView(title)
        val subtitle = TextView(this)
        subtitle.text = "Your phone. Your island."
        subtitle.textSize = 14f
        subtitle.setTextColor(Color.LTGRAY)
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, dp(6), 0, dp(18))
        root.addView(subtitle)

        // ---- status + start/stop ----
        val c1 = card(root, "STATUS")
        status = TextView(this)
        status.textSize = 13f
        status.setTextColor(accent)
        c1.addView(status)
        c1.addView(actionButton("START DYNAMIC ISLAND", true) {
            if (!Settings.canDrawOverlays(this)) {
                toast("Allow \"Display over other apps\" first.")
            } else {
                val i = Intent(this, IslandOverlayService::class.java)
                startForegroundService(i)
                status.postDelayed({ refresh() }, 700)
            }
        })
        c1.addView(actionButton("STOP DYNAMIC ISLAND", false) {
            prefs.edit().putBoolean(Prefs.RUNNING, false).apply()
            stopService(Intent(this, IslandOverlayService::class.java))
            status.postDelayed({ refresh() }, 500)
        })

        // ---- setup ----
        val c2 = card(root, "SETUP (ONE TIME)")
        c2.addView(actionButton("1 · Allow display over other apps", false) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        c2.addView(actionButton("2 · Allow restricted settings (App info → ⋮)", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        c2.addView(actionButton("3 · Enable notification access", false) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        c2.addView(actionButton("4 · Allow phone permission (call timer)", false) {
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 41)
            }
        })
        if (Build.VERSION.SDK_INT >= 33) {
            c2.addView(actionButton("5 · Allow notifications", false) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
            })
        }
        c2.addView(actionButton("6 · Battery: set to Unrestricted", false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        c2.addView(note("If \"Notification access\" is greyed out, use step 2 first: tap ⋮ (top right) → Allow restricted settings. Android blocks it for apps installed from outside the Play Store."))

        // ---- camera alignment ----
        val c3 = card(root, "CAMERA ALIGNMENT")
        camInfo = note("")
        c3.addView(camInfo)
        toggle(c3, "Calibration mode (shows the pill in grey)", Prefs.CALIBRATION, false)
        slider(c3, "Width", Prefs.ADJ_W, -12, 30)
        slider(c3, "Height", Prefs.ADJ_H, -12, 20)
        slider(c3, "Move left / right", Prefs.OFF_X, -30, 30)
        slider(c3, "Move up / down", Prefs.OFF_Y, -30, 30)
        c3.addView(actionButton("Reset alignment", false) {
            prefs.edit().putInt(Prefs.ADJ_W, 0).putInt(Prefs.ADJ_H, 0)
                .putInt(Prefs.OFF_X, 0).putInt(Prefs.OFF_Y, 0).apply()
            recreate()
        })
        c3.addView(note("Turn on calibration mode with the island running. The grey pill should sit exactly around your camera hole. Nudge the sliders until it does, then switch calibration off."))

        // ---- behaviour ----
        val c4 = card(root, "BEHAVIOUR")
        toggle(c4, "Hide pill when idle (blends with camera)", Prefs.HIDE_IDLE, true)
        toggle(c4, "Show notifications", Prefs.NOTIFS, true)
        toggle(c4, "Charging animation", Prefs.CHARGING, true)
        toggle(c4, "Haptic feedback", Prefs.HAPTICS, true)
        toggle(c4, "Start automatically after reboot / update", Prefs.AUTOSTART, true)

        // ---- try it ----
        val c5 = card(root, "TRY IT")
        c5.addView(actionButton("Preview notification", false) {
            val s = IslandBus.overlay
            if (s == null) toast("Start the island first.") else s.demoNotification()
        })
        c5.addView(actionButton("Preview charging", false) {
            val s = IslandBus.overlay
            if (s == null) toast("Start the island first.") else s.demoCharging()
        })
        c5.addView(note("Gestures: tap the pill to open · long-press for the quick panel (torch, focus timer, volume) · swipe up to close · swipe left/right on the top bar to switch pages."))

        root.addView(note("Everything stays on this device. No internet permission, no analytics.").apply { gravity = Gravity.CENTER })
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = if (Settings.canDrawOverlays(this)) "✓ Overlay permission" else "✗ Overlay permission needed"
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val listener = if (enabled?.contains(packageName) == true) "✓ Notification access" else "✗ Notification access needed"
        val running = if (IslandBus.overlay != null) "✓ Island running" else "○ Island stopped"
        status.text = "$overlay\n$listener\n$running"
        val g = CameraGeometry.read(this)
        val d = resources.displayMetrics.density
        camInfo.text = if (g.detected) {
            "Camera detected: ${(g.width / d).toInt()}×${(g.height / d).toInt()} dp, centre at x=${(g.centerX / d).toInt()}, y=${(g.centerY / d).toInt()} dp."
        } else {
            "Android did not report a camera cutout, so defaults are used. Use the sliders to align."
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun card(parent: LinearLayout, heading: String): LinearLayout {
        val h = TextView(this)
        h.text = heading
        h.textSize = 11f
        h.setTextColor(Color.GRAY)
        h.letterSpacing = .12f
        h.setPadding(dp(4), dp(18), 0, dp(8))
        parent.addView(h)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(10), dp(14), dp(12))
        val d = GradientDrawable()
        d.setColor(panel)
        d.cornerRadius = dp(18).toFloat()
        c.background = d
        parent.addView(c, LinearLayout.LayoutParams(-1, -2))
        return c
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 11.5f
        t.setTextColor(Color.GRAY)
        t.setPadding(0, dp(8), 0, dp(4))
        return t
    }

    private fun toggle(parent: LinearLayout, label: String, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.text = label
        sw.setTextColor(Color.WHITE)
        sw.textSize = 14f
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, dp(6), 0, dp(6))
        parent.addView(sw, p)
    }

    private fun slider(parent: LinearLayout, label: String, key: String, min: Int, maxV: Int) {
        val value = prefs.getInt(key, 0)
        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = 13f
        fun setTitle(v: Int) {
            title.text = label + ": " + (if (v > 0) "+" else "") + v + " dp"
        }
        setTitle(value)
        val sb = SeekBar(this)
        sb.max = maxV - min
        sb.progress = value - min
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + min
                setTitle(v)
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.setMargins(0, dp(10), 0, 0)
        parent.addView(title, tp)
        parent.addView(sb, LinearLayout.LayoutParams(-1, -2))
    }

    private fun actionButton(label: String, primary: Boolean, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(if (primary) Color.BLACK else Color.WHITE)
        b.setBackgroundColor(if (primary) accent else Color.rgb(29, 32, 41))
        b.setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, dp(5), 0, dp(5))
        b.layoutParams = p
        return b
    }
}
