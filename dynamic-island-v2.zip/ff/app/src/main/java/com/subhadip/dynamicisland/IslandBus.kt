package com.subhadip.dynamicisland

import android.app.PendingIntent
import android.graphics.drawable.Drawable

class IslandAction(val title: String, val intent: PendingIntent)

/** A notification boiled down to what the island needs. */
class IslandNotif(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val icon: Drawable?,
    val contentIntent: PendingIntent?,
    val actions: List<IslandAction>,
    val isCall: Boolean,
    val incoming: Boolean,
    val whenMs: Long,
    val showsChronometer: Boolean
)

/** Tiny in-process hub so the notification listener can reach the overlay service. */
object IslandBus {
    @JvmField
    var overlay: IslandOverlayService? = null
}
