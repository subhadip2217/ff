package com.subhadip.dynamicisland

import android.app.Notification
import android.app.NotificationManager
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {

    companion object {
        @JvmField
        var instance: IslandNotificationListener? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        IslandBus.overlay?.onListenerConnected()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val overlay = IslandBus.overlay ?: return
        val n = convert(sbn) ?: return
        overlay.onIslandNotification(n)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        IslandBus.overlay?.onIslandNotificationRemoved(sbn.key)
    }

    /** Call notifications that are already showing (used when the island starts mid-call). */
    fun activeCall(): IslandNotif? {
        return try {
            activeNotifications
                ?.mapNotNull { convert(it) }
                ?.firstOrNull { it.isCall }
        } catch (_: Exception) {
            null
        }
    }

    fun convert(sbn: StatusBarNotification?): IslandNotif? {
        if (sbn == null) return null
        val n = sbn.notification ?: return null
        if (sbn.packageName == packageName) return null
        val extras = n.extras
        val isCall = n.category == Notification.CATEGORY_CALL

        if (!isCall) {
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return null
            if (sbn.isOngoing) return null
            val cat = n.category
            if (cat == Notification.CATEGORY_TRANSPORT ||
                cat == Notification.CATEGORY_PROGRESS ||
                cat == Notification.CATEGORY_SERVICE ||
                cat == Notification.CATEGORY_SYSTEM
            ) return null
            if (extras != null && extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) return null
            // Respect the user's importance / Do-Not-Disturb choices.
            try {
                val ranking = Ranking()
                if (currentRanking.getRanking(sbn.key, ranking)) {
                    if (ranking.importance < NotificationManager.IMPORTANCE_DEFAULT) return null
                    if (!ranking.matchesInterruptionFilter()) return null
                }
            } catch (_: Exception) {
            }
        }

        val title = (extras?.getCharSequence(Notification.EXTRA_TITLE) ?: "").toString()
        val text = (extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras?.getCharSequence(Notification.EXTRA_TEXT) ?: "").toString()
        if (!isCall && title.isBlank() && text.isBlank()) return null

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            sbn.packageName
        }
        var icon: Drawable? = try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (_: Exception) {
            null
        }
        if (icon == null) {
            icon = try {
                n.smallIcon?.loadDrawable(this)
            } catch (_: Exception) {
                null
            }
        }

        val actions = ArrayList<IslandAction>()
        n.actions?.forEach { a ->
            val pi = a.actionIntent
            val remote = a.remoteInputs
            if (pi != null && (remote == null || remote.isEmpty())) {
                actions.add(IslandAction(a.title?.toString() ?: "", pi))
            }
        }

        val callType = extras?.getInt("android.callType", 0) ?: 0
        val incoming = isCall && when (callType) {
            1 -> true
            2 -> false
            else -> actions.size >= 2
        }

        return IslandNotif(
            key = sbn.key,
            pkg = sbn.packageName,
            appName = appName,
            title = title,
            text = text,
            icon = icon,
            contentIntent = n.contentIntent,
            actions = actions,
            isCall = isCall,
            incoming = incoming,
            whenMs = n.`when`,
            showsChronometer = extras?.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false) ?: false
        )
    }
}
