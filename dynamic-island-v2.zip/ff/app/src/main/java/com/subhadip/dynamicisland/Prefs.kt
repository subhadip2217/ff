package com.subhadip.dynamicisland

import android.content.Context
import android.content.SharedPreferences

/** All user settings live here so the settings screen and the overlay service stay in sync. */
object Prefs {
    const val FILE = "island_prefs"

    // Camera alignment (dp, relative to what Android reports for the cutout)
    const val ADJ_W = "adj_w"
    const val ADJ_H = "adj_h"
    const val OFF_X = "off_x"
    const val OFF_Y = "off_y"
    const val CALIBRATION = "calibration"

    // Behaviour
    const val HIDE_IDLE = "hide_idle"
    const val HAPTICS = "haptics"
    const val NOTIFS = "notifs"
    const val CHARGING = "charging"
    const val AUTOSTART = "autostart"
    const val RUNNING = "running"

    fun get(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
