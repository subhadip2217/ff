package com.subhadip.dynamicisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Restarts the island after a reboot or an app update, if it was running before. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val prefs = Prefs.get(context)
        if (!prefs.getBoolean(Prefs.AUTOSTART, true)) return
        if (!prefs.getBoolean(Prefs.RUNNING, false)) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            context.startForegroundService(Intent(context, IslandOverlayService::class.java))
        } catch (_: Exception) {
        }
    }
}
