package com.subhadip.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class Glyph { PLAY, PAUSE, NEXT, PREV, BOLT, PHONE, TORCH, TIMER, GEAR }

/** Small hand-drawn icons so we need no image assets. */
class GlyphView(context: Context, var glyph: Glyph, var tint: Int = Color.WHITE) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()

    fun set(g: Glyph, color: Int) {
        glyph = g
        tint = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        paint.color = tint
        paint.style = Paint.Style.FILL
        paint.strokeCap = Paint.Cap.BUTT
        val r = w * 0.05f
        when (glyph) {
            Glyph.PLAY -> {
                path.reset()
                path.moveTo(w * 0.32f, h * 0.2f)
                path.lineTo(w * 0.82f, h * 0.5f)
                path.lineTo(w * 0.32f, h * 0.8f)
                path.close()
                canvas.drawPath(path, paint)
            }
            Glyph.PAUSE -> {
                canvas.drawRoundRect(w * 0.27f, h * 0.2f, w * 0.43f, h * 0.8f, r, r, paint)
                canvas.drawRoundRect(w * 0.57f, h * 0.2f, w * 0.73f, h * 0.8f, r, r, paint)
            }
            Glyph.NEXT -> {
                path.reset()
                path.moveTo(w * 0.2f, h * 0.22f)
                path.lineTo(w * 0.62f, h * 0.5f)
                path.lineTo(w * 0.2f, h * 0.78f)
                path.close()
                canvas.drawPath(path, paint)
                canvas.drawRoundRect(w * 0.68f, h * 0.22f, w * 0.8f, h * 0.78f, r, r, paint)
            }
            Glyph.PREV -> {
                path.reset()
                path.moveTo(w * 0.8f, h * 0.22f)
                path.lineTo(w * 0.38f, h * 0.5f)
                path.lineTo(w * 0.8f, h * 0.78f)
                path.close()
                canvas.drawPath(path, paint)
                canvas.drawRoundRect(w * 0.2f, h * 0.22f, w * 0.32f, h * 0.78f, r, r, paint)
            }
            Glyph.BOLT -> {
                path.reset()
                path.moveTo(w * 0.58f, h * 0.04f)
                path.lineTo(w * 0.22f, h * 0.56f)
                path.lineTo(w * 0.46f, h * 0.56f)
                path.lineTo(w * 0.40f, h * 0.96f)
                path.lineTo(w * 0.78f, h * 0.42f)
                path.lineTo(w * 0.54f, h * 0.42f)
                path.close()
                canvas.drawPath(path, paint)
            }
            Glyph.PHONE -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = w * 0.17f
                paint.strokeCap = Paint.Cap.ROUND
                oval.set(w * 0.2f, h * 0.2f, w * 0.8f, h * 0.8f)
                canvas.drawArc(oval, 105f, 130f, false, paint)
            }
            Glyph.TORCH -> {
                path.reset()
                path.moveTo(w * 0.3f, h * 0.06f)
                path.lineTo(w * 0.7f, h * 0.06f)
                path.lineTo(w * 0.62f, h * 0.32f)
                path.lineTo(w * 0.38f, h * 0.32f)
                path.close()
                canvas.drawPath(path, paint)
                canvas.drawRoundRect(w * 0.38f, h * 0.37f, w * 0.62f, h * 0.94f, r * 2, r * 2, paint)
            }
            Glyph.TIMER -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = w * 0.09f
                paint.strokeCap = Paint.Cap.ROUND
                canvas.drawCircle(w * 0.5f, h * 0.56f, w * 0.34f, paint)
                canvas.drawLine(w * 0.5f, h * 0.56f, w * 0.5f, h * 0.36f, paint)
                canvas.drawLine(w * 0.5f, h * 0.56f, w * 0.64f, h * 0.62f, paint)
                canvas.drawLine(w * 0.4f, h * 0.08f, w * 0.6f, h * 0.08f, paint)
            }
            Glyph.GEAR -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = w * 0.09f
                paint.strokeCap = Paint.Cap.ROUND
                canvas.drawCircle(w * 0.5f, h * 0.5f, w * 0.2f, paint)
                for (i in 0 until 8) {
                    val a = (i * Math.PI / 4).toFloat()
                    val c = cos(a)
                    val s = sin(a)
                    canvas.drawLine(
                        w * 0.5f + c * w * 0.3f, h * 0.5f + s * h * 0.3f,
                        w * 0.5f + c * w * 0.42f, h * 0.5f + s * h * 0.42f, paint
                    )
                }
            }
        }
    }
}

/** Animated equaliser bars shown while music plays. */
class EqView(context: Context) : View(context) {
    var tint: Int = Color.rgb(89, 230, 210)
    var playing: Boolean = true
        set(value) {
            if (value != field) {
                field = value
                invalidate()
            }
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        paint.color = tint
        val bars = 4
        val gap = w * 0.1f
        val bw = (w - gap * (bars - 1)) / bars
        val t = SystemClock.uptimeMillis() / 1000f
        for (i in 0 until bars) {
            val f = if (playing) 0.3f + 0.7f * abs(sin(t * (2.1f + i * 0.85f) + i * 1.3f)) else 0.25f
            val bh = h * f
            val left = i * (bw + gap)
            val top = (h - bh) / 2f
            canvas.drawRoundRect(left, top, left + bw, top + bh, bw / 2f, bw / 2f, paint)
        }
        if (playing) postInvalidateOnAnimation()
    }
}

/** Thin iOS-style progress / volume bar. */
class ThinSeek(context: Context) : View(context) {
    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var interactive: Boolean = true
    var fill: Int = Color.WHITE
    var dragging: Boolean = false
        private set
    var onChange: ((Float) -> Unit)? = null
    var onCommit: ((Float) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val th = if (dragging) h * 0.32f else h * 0.2f
        val top = (h - th) / 2f
        paint.color = Color.argb(70, 255, 255, 255)
        canvas.drawRoundRect(0f, top, w, top + th, th / 2f, th / 2f, paint)
        paint.color = fill
        canvas.drawRoundRect(0f, top, w * progress, top + th, th / 2f, th / 2f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                move(e.x)
            }
            MotionEvent.ACTION_MOVE -> move(e.x)
            MotionEvent.ACTION_UP -> {
                move(e.x)
                dragging = false
                onCommit?.invoke(progress)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                invalidate()
            }
        }
        return true
    }

    private fun move(x: Float) {
        if (width > 0) {
            progress = x / width
            onChange?.invoke(progress)
        }
    }
}

/** The black island itself. Lets the service watch touches (swipes, long-press) without stealing clicks. */
class IslandCard(context: Context) : FrameLayout(context) {
    var touchHook: ((MotionEvent) -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        touchHook?.invoke(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        pivotX = w / 2f
    }
}
