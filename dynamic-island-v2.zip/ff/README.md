# Dynamic Island

Native Kotlin Android Dynamic Island overlay, tuned for the Motorola G45 5G (and other punch-hole Android phones).
No analytics, ads, accounts, or Internet permission.

## What it does

The island sits exactly around your front camera. Idle, it is invisible (it blends with the camera hole).
When something happens it grows out of the camera, with compact icons either side of the hole, just like on iPhone.

| Page | What you see |
|---|---|
| Notifications | App icon, title and text pop out for a few seconds. Tap to open the app, swipe up to dismiss. Respects Do Not Disturb. |
| Music | Artwork, track, live progress and seek bar, prev / play / next, volume, animated equaliser. Tap to open the player. |
| Calls | Caller name, live call timer, Answer / Decline / Hang up buttons (taken from the dialer's own notification). |
| Focus timer | Countdown in the pill (25 / 50 min presets for study sessions), pause, +5 min, stop, vibrates when done. |
| Charging | Plug-in animation, battery %, time to full. Low-battery warning at 15%. |
| Quick panel | Long-press the pill: torch, focus timers, volume. |

Gestures: tap = open/close, long-press = quick panel, swipe down = open, swipe up = close, swipe left/right on the top bar = next page.

## Setup (one time)

1. Install the APK and open **Dynamic Island**.
2. Allow **Display over other apps**.
3. Tap **Allow restricted settings** → in App info tap the **⋮** menu → *Allow restricted settings*.
   (Android 13+ blocks Notification Access for apps installed outside the Play Store until you do this.)
4. Enable **Notification access** for Dynamic Island.
5. Allow the phone permission (call timer) and notifications.
6. Set battery usage to **Unrestricted** so the island is never killed.
7. Tap **Start Dynamic Island**.

## Camera alignment

The app asks Android where the camera cutout is and centres the island on it. If it is off by a few pixels on your phone:

1. Open the app → **Camera alignment** → turn on **Calibration mode**. The pill turns grey so you can see it.
2. Nudge **Width / Height / Move left-right / Move up-down** until it hugs the camera hole.
3. Turn calibration mode off.

## Build

Every push to `main` builds a debug APK with GitHub Actions. Download it from **Releases** (easiest on a phone)
or from **Actions → Build Android APK → Artifacts**. The APK is signed with a fixed key, so new builds install over old ones.
